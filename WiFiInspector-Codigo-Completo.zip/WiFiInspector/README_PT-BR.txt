WIFI INSPECTOR — PROJETO ANDROID

Este projeto é um exemplo educativo e local. Ele inclui:
- estimativa simples de força de senha;
- calculadora matemática de combinações;
- dicas básicas de segurança.

Ele não se conecta a redes Wi-Fi, não testa senhas de redes e não tenta acessar redes alheias.

COMO ABRIR NO COMPUTADOR
1. Instale o Android Studio: https://developer.android.com/studio
2. Extraia o ZIP.
3. No Android Studio, escolha Open e selecione a pasta WiFiInspector.
4. Aguarde a sincronização do Gradle.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).

O APK de depuração costuma aparecer em:
app/build/outputs/apk/debug/app-debug.apk

NOTA
O projeto usa Android Gradle Plugin 8.6.1 e compileSdk 35. Se o Android Studio pedir componentes do SDK, aceite a instalação.
