package com.example.wifiinspector;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.math.BigInteger;

public class MainActivity extends Activity {
    private LinearLayout layout;
    private EditText senha;
    private EditText tamanho;
    private EditText caracteres;
    private TextView resultado;

    private int dp(float valor) {
        return (int) (valor * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(15, 23, 42));

        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(22), dp(25), dp(22), dp(25));
        scroll.addView(layout);
        setContentView(scroll);

        TextView titulo = new TextView(this);
        titulo.setText("WiFi Inspector");
        titulo.setTextSize(30);
        titulo.setTypeface(null, Typeface.BOLD);
        titulo.setTextColor(Color.WHITE);
        titulo.setGravity(Gravity.CENTER);
        adicionar(titulo);

        TextView subtitulo = new TextView(this);
        subtitulo.setText("Ferramentas para entender a segurança de senhas");
        subtitulo.setTextSize(15);
        subtitulo.setTextColor(Color.LTGRAY);
        subtitulo.setGravity(Gravity.CENTER);
        adicionar(subtitulo);

        separador();
        texto("1. Verificador de senha");
        senha = campo("Digite uma senha para avaliar");

        Button verificar = botao("Verificar força da senha");
        verificar.setOnClickListener(v -> verificarSenha());
        layout.addView(verificar);

        resultado = new TextView(this);
        resultado.setTextColor(Color.WHITE);
        resultado.setTextSize(16);
        adicionar(resultado);

        separador();
        texto("2. Calculadora de combinações");
        tamanho = campo("Tamanho da senha (ex.: 8)");
        tamanho.setInputType(2);
        caracteres = campo("Quantidade de caracteres possíveis (ex.: 26)");
        caracteres.setInputType(2);

        Button calcular = botao("Calcular combinações");
        calcular.setOnClickListener(v -> calcularCombinacoes());
        layout.addView(calcular);

        separador();
        texto("3. Demonstração local");

        TextView demo = new TextView(this);
        demo.setText("Esta demonstração não se conecta a redes Wi-Fi. Ela explica conceitos de segurança de senhas.");
        demo.setTextColor(Color.LTGRAY);
        demo.setTextSize(15);
        adicionar(demo);

        Button demonstrar = botao("Mostrar dica de segurança");
        demonstrar.setOnClickListener(v -> resultado.setText(
            "Dica: use uma senha longa e exclusiva, com palavras ou caracteres variados. " +
            "Ative WPA2-AES ou WPA3 no roteador e desative o WPS se não precisar dele."
        ));
        layout.addView(demonstrar);
    }

    private void adicionar(TextView view) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, dp(8), 0, dp(8));
        layout.addView(view, params);
    }

    private void texto(String valor) {
        TextView view = new TextView(this);
        view.setText(valor);
        view.setTextSize(20);
        view.setTypeface(null, Typeface.BOLD);
        view.setTextColor(Color.rgb(96, 165, 250));
        adicionar(view);
    }

    private EditText campo(String dica) {
        EditText edit = new EditText(this);
        edit.setHint(dica);
        edit.setTextColor(Color.WHITE);
        edit.setHintTextColor(Color.LTGRAY);
        edit.setSingleLine(true);
        edit.setPadding(dp(12), dp(8), dp(12), dp(8));
        edit.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(96, 165, 250)));
        adicionar(edit);
        return edit;
    }

    private Button botao(String nome) {
        Button button = new Button(this);
        button.setText(nome);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(37, 99, 235)));
        return button;
    }

    private void separador() {
        TextView espaco = new TextView(this);
        espaco.setText("────────────────────");
        espaco.setTextColor(Color.DKGRAY);
        espaco.setGravity(Gravity.CENTER);
        adicionar(espaco);
    }

    private void verificarSenha() {
        String valor = senha.getText().toString();
        if (valor.isEmpty()) {
            resultado.setText("Digite uma senha primeiro.");
            return;
        }

        int pontos = 0;
        if (valor.length() >= 8) pontos++;
        if (valor.length() >= 12) pontos++;
        if (valor.matches(".*[A-Z].*")) pontos++;
        if (valor.matches(".*[a-z].*")) pontos++;
        if (valor.matches(".*[0-9].*")) pontos++;
        if (valor.matches(".*[^a-zA-Z0-9].*")) pontos++;

        String nivel = pontos <= 2 ? "Fraca" : (pontos <= 4 ? "Média" : "Forte");
        resultado.setText("Resultado: " + nivel + "\nComprimento: " + valor.length() +
            " caracteres.\n\nEsta é uma estimativa simples, não uma garantia de segurança.");
    }

    private void calcularCombinacoes() {
        try {
            int n = Integer.parseInt(tamanho.getText().toString().trim());
            int c = Integer.parseInt(caracteres.getText().toString().trim());

            if (n < 1 || n > 1000 || c < 2 || c > 1000000) {
                resultado.setText("Use tamanho entre 1 e 1000 e quantidade de caracteres entre 2 e 1000000.");
                return;
            }

            BigInteger total = BigInteger.valueOf(c).pow(n);
            resultado.setText("Espaço teórico de combinações: " + total +
                "\n\nEsse número representa possibilidades matemáticas, não o tempo real para descobrir uma senha.");
        } catch (NumberFormatException e) {
            resultado.setText("Preencha os dois campos com números válidos.");
        }
    }
}
